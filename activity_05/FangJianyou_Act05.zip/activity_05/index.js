function main() {
    window.location = `/FangJianyou_Act05.html`;
}
