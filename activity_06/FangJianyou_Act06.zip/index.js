function main() {
    window.location = `/FangJianyou_Act06.html`;
}
