Please run this project using node http-server.

1) First install node http-server:

  $ npm install -g http-server

2) Then start the server under root directory:

  $ http-server

3) Open browser, visit http://localhost:8080/ to check my project.
