function main() {
    window.location = `/FangJianyou_ProjB.html`;
}
